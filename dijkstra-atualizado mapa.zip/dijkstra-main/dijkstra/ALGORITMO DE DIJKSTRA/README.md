# Algoritmo_de_Dijkstra

# Aqui deixamos comentado o que a explicação do código, certo?
# por exemplo: Esse projeto foi feito pelos alunos do segundo período
# 2025/1 com o intuíto de fazer um algoritimo para o Djikstra 
