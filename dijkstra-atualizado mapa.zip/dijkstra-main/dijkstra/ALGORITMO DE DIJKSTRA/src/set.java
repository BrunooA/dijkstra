package src;

public class set<T> {

}
